



    import UIKit
    import CoreData
    class ViewController: UIViewController,UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
      var imagePicker: UIImagePickerController!
    
    @IBOutlet var enterT : UITextField!
    @IBOutlet var pic : UIImageView!
    lazy var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        pic.backgroundColor = .cyan
        populateData()
    }

    
    
    
    func loadImage(at index : Int) {
        let fetchRequest = NSFetchRequest<Users>(entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "idx == %d", Int32(index))
        do {
            if let user = try context.fetch(fetchRequest).first {
                pic.image = UIImage(data: user.image!)
            } else {
                pic.image = nil
            }
        } catch {
            print("Could not fetch \(error) ")
        }
    }
    
    @IBAction func add(){
          imagePicker =  UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
        
    }
    @IBAction func append(){

    }
    
    func populateData()
    {
        let item = Users(context: context)
        let vex = UIImage(named: "on.jpg")!.pngData()
        item.image = vex
        item.idx = 0
        

        
        print("Storing Data..")
        do {
            try context.save()
        } catch {
            print("Storing data Failed", error)
        }
    }
    

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        // The info dictionary may contain multiple representations of the image. You want to use the original.
        guard let selectedImage = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        

        
        pic.image = selectedImage
        
        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let ac = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        } else {
            let ac = UIAlertController(title: "Saved!", message: "Your altered image has been saved to your photos.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        }
    }
}
